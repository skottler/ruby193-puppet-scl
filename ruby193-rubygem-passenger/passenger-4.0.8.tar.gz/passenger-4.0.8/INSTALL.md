# Installing Phusion Passenger

Please read README.md for installation instructions.

If you're having trouble installing Phusion Passenger, please read the file `doc/Users guide Apache.html` or `doc/Users guide Nginx.html`, depending on whether you want to install Phusion Passenger for Apache or for Nginx.

Documentation and support resources are also available on [the website](https://www.phusionpassenger.com/support).
