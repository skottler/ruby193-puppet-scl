module FooHelper
end
