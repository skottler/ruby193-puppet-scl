module BarHelper
end
